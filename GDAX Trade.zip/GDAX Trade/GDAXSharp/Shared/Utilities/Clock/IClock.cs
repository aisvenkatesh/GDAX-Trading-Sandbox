﻿using System;

namespace GDAXSharp.Shared.Utilities.Clock
{
    public interface IClock
    {
        DateTime GetTime();
    }
}
