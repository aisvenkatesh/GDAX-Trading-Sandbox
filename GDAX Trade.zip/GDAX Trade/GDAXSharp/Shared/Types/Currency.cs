﻿namespace GDAXSharp.Shared.Types
{
    public enum Currency
    {
        USD,
        EUR,
        GBP,
        BTC,
        LTC,
        ETH,
        BCH
    }
}
