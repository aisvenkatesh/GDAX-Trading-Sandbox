﻿namespace GDAXSharp.Exceptions
{
    public class GDAXErrorMessage
    {
        public string Message { get; set; }
    }
}
