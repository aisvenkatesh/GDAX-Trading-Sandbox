﻿using GDAXSharp.Network.Authentication;
using GDAXSharp.Network.HttpClient;
using GDAXSharp.Network.HttpRequest;
using GDAXSharp.Services.Orders;
using GDAXSharp.Services.Orders.Types;
using GDAXSharp.Shared;
using GDAXSharp.Shared.Types;
using GDAXSharp.Shared.Utilities.Clock;
using GDAXSharp.Shared.Utilities.Queries;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace GDAXSharp
{
    public class GDAXClient
    {

        public static void Main(string[] args)
        {
            var authenticator = new Authenticator();
            
            var gdaxClient = new GDAXClient(authenticator, true);

            Task.Run(async () =>
            {
                var response = await gdaxClient.OrdersService.PlaceLimitOrderAsync(OrderSide.Sell, ProductType.BtcUsd,0.1m, 1);
                Thread.Sleep(2000);
                var res = await gdaxClient.OrdersService.GetOrderByIdAsync(response.Id);
            }).GetAwaiter().GetResult();

        }

        public GDAXClient(
            IAuthenticator authenticator,
            bool sandBox = false)
                : this(authenticator, new HttpClient(), sandBox)
        {
        }

        public GDAXClient(
            IAuthenticator authenticator,
            IHttpClient httpClient,
            bool sandBox = false)
        {
            var clock = new Clock();
            var httpRequestMessageService = new HttpRequestMessageService(authenticator, clock, sandBox);
            var queryBuilder = new QueryBuilder();


            OrdersService = new OrdersService(httpClient, httpRequestMessageService);

        }

        public OrdersService OrdersService { get; }

       
    }
}
